/*!tests!
 *
 * {
 *    "input":      [],
 *    "exception":  "OutOfMemoryError"
 * }
 *
 */

#include "cminus.h"

void main() {
    int x = 10000000000000 ;
    print_int(1) ;
}

