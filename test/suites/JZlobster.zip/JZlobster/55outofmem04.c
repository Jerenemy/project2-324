/*!tests!
 *
 * {
 *    "input":      [],
 *    "exception":  "OutOfMemoryError"
 * }
 *
 */

#include "cminus.h"

void main() {
    int x = 4294967295 ;
    print_int(1) ;
}

