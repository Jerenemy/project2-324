/*!tests!
 *
 * {
 *  "input":    [],
 *  "output":   []
 * }
 *
 */

#include "cminus.h"

void main() {
    int x[0] ;

    return ;
}
