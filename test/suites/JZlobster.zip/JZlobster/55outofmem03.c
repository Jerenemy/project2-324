/*!tests!
 *
 * {
 *    "input":      [],
 *    "exception":  "OutOfMemoryError"
 * }
 *
 */

#include "cminus.h"

void main() {
    int x = 2147483648 ;
    print_int(1) ;
}

