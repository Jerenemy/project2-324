/*!tests!
 *
 * {
 *    "input":      [],
 *    "exception":  "SegmentationError"
 * }
 *
 */

#include "cminus.h"

void main() {
    int xs [0] ;
    xs[0] = 1 ;
    print_int(1) ;
}

