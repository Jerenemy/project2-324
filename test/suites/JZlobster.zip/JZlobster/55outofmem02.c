/*!tests!
 *
 * {
 *    "input":      [],
 *    "exception":  "OutOfMemoryError"
 * }
 *
 */

#include "cminus.h"

void main() {
    int x = 2147483647 ;
    print_int(1) ;
}

