/*!tests!
 *
 * {
 *  "input":    [],
 *  "output":   []
 * }
 *
 */

#include "cminus.h"

int assign_arr(int x) {
    int xs[x] ;
    return x ; 
}


void main() {
    int x = assign_arr(1) ;

    return ;
}
